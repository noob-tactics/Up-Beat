package com.example.upbeatdemo;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

public class PlaylistActivity extends Activity implements OnClickListener{
	ImageButton createPlaylist;
	DatabaseHelper dh;
	static ArrayList<Model_Playlist> playlists;
	ListView lv;
	String songs[];
	Model_Playlist p;
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);
        
       
        dh = new DatabaseHelper(getApplicationContext());
        
       
        playlists = dh.getAllPlaylist();
       
        lv = (ListView) findViewById(R.id.playlistview);
        
        PlaylistAdapter adapter = new PlaylistAdapter(playlists, getApplicationContext());
        lv.setAdapter(adapter);
        
        lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				// TODO Auto-generated method stub
				
				String title = playlists.get(position).getPlaylistName();
				
				int id = playlists.get(position).getId();
				p=dh.getSongsFromPlaylist(id);
				songs=convertStringToArray(p.getContent());
				Intent i = new Intent(PlaylistActivity.this,PlayPlaylistActivity.class).putExtra("songs", songs).putExtra("title", title).putExtra("pos", position);
				startActivity(i);
				
			}
        	
        });
         
        createPlaylist = (ImageButton) findViewById(R.id.imageButton1);
        createPlaylist.setOnClickListener(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_playlist, menu);
        return true;
    }

	@Override
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		Intent i = new Intent(PlaylistActivity.this,NewPlaylistActivity.class);
		startActivity(i);
	}
	
	 public static String[] convertStringToArray(String str){
	        String[] arr = str.split(",");
	        return arr;
	    }
    
}
