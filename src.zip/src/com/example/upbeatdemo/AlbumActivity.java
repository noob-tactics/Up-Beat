package com.example.upbeatdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;

public class AlbumActivity extends Activity {
	GridView gv;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_album);
        
        gv = (GridView) findViewById(R.id.AlbumgridView);
         
        AlbumAdapter adapter = new AlbumAdapter(getApplicationContext(),TabActivity.albumArt, TabActivity.album);
        gv.setAdapter(adapter);
        
        gv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				// TODO Auto-generated method stub
				Intent i = new Intent(AlbumActivity.this,PlayAlbumActivity.class).putExtra("albumPos",position);
				startActivity(i);
			}
		});
        
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_album, menu);
        return true;
    }

    
}
