package com.example.upbeatdemo;

import java.io.IOException;
import java.util.Random;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Player extends Activity {
	ImageButton play,next,FF,FB,prev,repeat,shuffle;
	SeekBar sb;
	int PlaylistPosition,position,AllSongPosition,AlbumPosition;
	static MediaPlayer mp;
	
	Uri u;
	static TextView song_title;
	static Thread updateSeek;
	static ImageView iv;
	boolean fromPlaylist,isRepeat,isShuffle,fromAlbum;

	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        if(mp!=null){
			mp.stop();
			mp.release();
		}
        updateSeek = new Thread(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				int totalduration = mp.getDuration();
				int currentposition = 0;
				sb.setMax(totalduration);
				while(currentposition < totalduration){
					try{
						sleep(500);
						currentposition = mp.getCurrentPosition();
						sb.setProgress(currentposition);
					}
					catch(InterruptedException e){
						e.printStackTrace();
					}
					catch(IllegalStateException e){
						e.printStackTrace();
					}
					
				}
			}
        };
        
        play = (ImageButton) findViewById(R.id.play);
		next = (ImageButton) findViewById(R.id.next);
		FF   = (ImageButton) findViewById(R.id.btFF);
		FB   = (ImageButton) findViewById(R.id.btFB);
		prev = (ImageButton) findViewById(R.id.prev);
		sb   = (SeekBar) findViewById(R.id.seekBar1);
		song_title = (TextView) findViewById(R.id.songTitle);
        iv = (ImageView) findViewById(R.id.AlbumView);
		repeat = (ImageButton)findViewById(R.id.imageButton1);
		shuffle = (ImageButton)findViewById(R.id.imageButton2);
		
        Intent i = getIntent();
        PlaylistPosition = i.getIntExtra("playlist_position",0);
		AllSongPosition = i.getIntExtra("pos", 0);
		AlbumPosition = i.getIntExtra("pos_album", 0);
		fromPlaylist = i.getBooleanExtra("FLAG",false);
		fromAlbum = i.getBooleanExtra("TAG", false);
		if(fromPlaylist)
			position = PlaylistPosition;
		else if(fromAlbum)
			position = AlbumPosition;
		else
			position = AllSongPosition;
		
		final int length;
		if(fromPlaylist)
			 length = PlayPlaylistActivity.playlist_songs.length;
		else if(fromAlbum)
			length = PlayAlbumActivity.title.length;	
			else	
			length = TabActivity.songPath.length;
		
		iv.setImageBitmap(TabActivity.Bmap[position]);
		
		song_title.setText(TabActivity.songTitle[position]);
		
		u = Uri.parse(TabActivity.songPath[position]);
		mp = MediaPlayer.create(getApplicationContext(), u);
		
		try {
			mp.prepare();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mp.start();
		updateSeek.start();
		
		mp.setOnCompletionListener(new OnCompletionListener() {
			
			@Override
			public void onCompletion(MediaPlayer arg0) {
				// TODO Auto-generated method stub
				
				if(isRepeat){
						position=position%length;
				}
				else if(isShuffle){
					Random r = new Random();
					position = r.nextInt(length);	
					position=position%length;
					
				}
				else{
					position = (position+1)%length;
					
				}
				
				mp.stop();
				mp.release();
				u = Uri.parse(TabActivity.songPath[position]);
				mp = MediaPlayer.create(getApplicationContext(), u);
				
				try {
					mp.prepareAsync();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				iv.setImageBitmap(TabActivity.Bmap[position]);
				mp.seekTo(mp.getCurrentPosition());
				mp.start();
				song_title.setText(TabActivity.songTitle[position]);
			}
		});
		
		// OnClickListeners
		play.setOnClickListener(new View.OnClickListener() {
		
		@Override
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			if(mp.isPlaying()){
				mp.pause();
				play.setImageResource(R.drawable.btn_play);
			}
			else{
				
					try {
						mp.prepare();
					} catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					mp.start();
				
				play.setImageResource(R.drawable.btn_pause);
			}	
		}
		});
		
		FF.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mp.seekTo(mp.getCurrentPosition() + 5000);
			}
		});
		
		FB.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mp.seekTo(mp.getCurrentPosition() - 5000);
			}
		});
		
		next.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				
					
				mp.stop();
				mp.release();
				position = (position+1)%length;
				u = Uri.parse(TabActivity.songPath[position]);
				mp = MediaPlayer.create(getApplicationContext(), u);
				
				try {
					mp.prepareAsync();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				iv.setImageBitmap(TabActivity.Bmap[position]);
				mp.start();
				play.setImageResource(R.drawable.btn_pause);
				song_title.setText(TabActivity.songTitle[position]);
			}
		});
		
		prev.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				mp.stop();
				mp.release();
				position = (position-1<0)? length-1 : position-1;
				u = Uri.parse(TabActivity.songPath[position]);
				mp = MediaPlayer.create(getApplicationContext(), u);
				try {
					mp.prepareAsync();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				iv.setImageBitmap(TabActivity.Bmap[position]);
				mp.start();
				play.setImageResource(R.drawable.btn_pause);
				song_title.setText(TabActivity.songTitle[position]);
			}
		});
		
		repeat.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				 if(isRepeat){
	                    isRepeat = false;
	                    repeat.setImageResource(R.drawable.btn_repeat);
	                }else{
	                    // make repeat to true
	                    isRepeat = true;
	                    // make shuffle to false
	                    isShuffle = false;
	                    repeat.setImageResource(R.drawable.btn_repeat_pressed);
	                    shuffle.setImageResource(R.drawable.btn_shuffle);
	                }
			}
		});
		
		shuffle.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				 if(isShuffle){
	                    isShuffle = false;
	                    shuffle.setImageResource(R.drawable.btn_shuffle);
	                }else{
	                    // make repeat to true
	                    isShuffle= true;
	                     // make shuffle to false
	                    isRepeat = false;
	                    shuffle.setImageResource(R.drawable.btn_shuffle_pressed);
	                    repeat.setImageResource(R.drawable.btn_repeat);
	                }
			}
		});
		
		sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar sb) {
				// TODO Auto-generated method stub
				mp.seekTo(sb.getProgress());
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar sb) {
				// TODO Auto-generated method stub
				mp.seekTo(sb.getProgress());
			}
			
			@Override
			public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
				// TODO Auto-generated method stub
				
			}
		});
		
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_player, menu);
        return true;
    }
 

	
    
    
}
