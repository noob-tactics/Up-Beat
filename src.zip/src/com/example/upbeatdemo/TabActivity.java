package com.example.upbeatdemo;

import java.io.InputStream;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Intent;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.view.Menu;
import android.widget.RemoteViews;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.Toast;

public class TabActivity extends android.app.TabActivity {
	
	 private static final String SONGS_SPEC = "Songs";
	 private static final String ALBUM_SPEC = "Albums";
	 private static final String PLAYLIST_SPEC = "Playlist";
	 Resources r;
	 static String [] songTitle,songPath,songArtist,songDuration,songAlbum,songAlbumId,album;
	 static Bitmap[] Bmap;
	 static String [] albumId;
	 int count;
	 Cursor albumCursor;	
	 static Bitmap [] albumArt;
	 int backButtonCount=0;
		// setting PATH to external sd card
		// using MediaStore database to retrieve song Data
		Uri u = android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
		//details we wan't from MediaStore database
		String [] columns = { MediaStore.Audio.Media.DISPLAY_NAME,
					          MediaStore.Audio.Media.DATA,
					          MediaStore.Audio.Media.ARTIST,
					          MediaStore.Audio.Media.DURATION,
					          MediaStore.Audio.Media.ALBUM_ID,
					          MediaStore.Audio.Media.ALBUM
							};
	 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		Notification n = new Notification(R.drawable.logo1, "UpBeat", 10000);
		
		Intent i =new Intent(TabActivity.this,TabActivity.class);
		
		PendingIntent pi = PendingIntent.getActivity(TabActivity.this, 10000,i, 1234);	
		n.setLatestEventInfo(getApplicationContext(),"Up Beat", "this app is running smoothly", pi);
		nm.notify(1001, n);
        this.getSongs();
        try{
        this.getAlbum();
        }
        catch(ArrayIndexOutOfBoundsException e){
        	e.printStackTrace();
        }
        
        TabHost tabHost = getTabHost();
        			r  =  getResources();
        Intent extra = getIntent();
        int checkTab = extra.getIntExtra("FLAG", 0);
      
        
        	
        
        
        
        TabSpec songsSpec = tabHost.newTabSpec(SONGS_SPEC);
        songsSpec.setIndicator(SONGS_SPEC,r.getDrawable(R.drawable.songicon));
        songsSpec.setContent(new Intent(TabActivity.this,SongsActivity.class));
        
        TabSpec tab2Spec = tabHost.newTabSpec(ALBUM_SPEC);
        tab2Spec.setIndicator(ALBUM_SPEC,r.getDrawable(R.drawable.album));
        tab2Spec.setContent(new Intent(this,AlbumActivity.class));
        
        TabSpec playlistSpec = tabHost.newTabSpec(PLAYLIST_SPEC);
        playlistSpec.setIndicator(PLAYLIST_SPEC,r.getDrawable(R.drawable.playlisticon));
        playlistSpec.setContent(new Intent(this,PlaylistActivity.class));
        
        tabHost.addTab(songsSpec);
        tabHost.addTab(tab2Spec);
        tabHost.addTab(playlistSpec);
        tabHost.setCurrentTab(checkTab);
        
        
    }
    
   
    @Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		super.onBackPressed();
		 if(backButtonCount >= 1)
		    {
		        Intent intent = new Intent(Intent.ACTION_MAIN);
		        intent.addCategory(Intent.CATEGORY_HOME);
		        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		        startActivity(intent);
		    }
		    else
		    {
		        Toast.makeText(this, "Press the back button once again to close the application.", Toast.LENGTH_SHORT).show();
		        backButtonCount++;
		    }
	}


	public void getSongs(){
		int i = 0;
		try{
			//setting mCoursor , and querying about the data we need !!
			final Cursor mCursor = getContentResolver().query(u,columns,null,null,"LOWER(" + MediaStore.Audio.Media.TITLE + ") ASC");	
			count = mCursor.getCount();	
			
			songTitle = new String[count];
			songPath = new String[count];
			songArtist = new String[count];
			songAlbumId = new String[count];
			songDuration = new String[count];
			songAlbum = new String[count];
			Bmap = new Bitmap[count];
			
			
			if(mCursor.moveToFirst()){
				
				do{
					String songtitle = mCursor.getString(mCursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)).replace(".mp3","");
					songTitle[i] = songtitle; 
					String songpath = mCursor.getString(mCursor.getColumnIndex(MediaStore.Audio.Media.DATA));
					songPath[i] = songpath;
					String songartist = mCursor.getString(mCursor.getColumnIndex(MediaStore.Audio.Media.ARTIST));
					songArtist[i] = songartist;
					String songalbumid = mCursor.getString(mCursor.getColumnIndex(MediaStore.Audio.Media.ALBUM_ID));
					songAlbumId[i] = songalbumid;
					String songduration = mCursor.getString(mCursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
					songDuration[i] = songduration; 
					String albumName = mCursor.getString(mCursor.getColumnIndex(MediaStore.Audio.Media.ALBUM));
					songAlbum[i] = albumName;
					
					Bitmap artwork = null;
					try {
						Uri sArtworkUri = Uri.parse("content://media/external/audio/albumart");
						Uri uri = ContentUris.withAppendedId(sArtworkUri,Long.valueOf(songAlbumId[i]));

						ContentResolver res = getContentResolver();
						InputStream in = res.openInputStream(uri);
						artwork = BitmapFactory.decodeStream(in);
						Bmap[i] = artwork;
					} catch (Exception e) {
						Log.e("Exception", e.toString());
					}
					
					i++;
				}while(mCursor.moveToNext());
				
			}
			
		}
			catch(NullPointerException e){
				e.printStackTrace();
			}
			
	
}
    
    public void getAlbum(){
    	String[] album_query = {MediaStore.Audio.Albums.ALBUM,
    							MediaStore.Audio.Albums._ID,
    							MediaStore.Audio.Albums.ALBUM_ART};
    	
    	albumCursor=getContentResolver().query(MediaStore.Audio.Albums.EXTERNAL_CONTENT_URI,album_query,null, null, null);
        
    	int albumCount = albumCursor.getCount();
    	album = new String[albumCount];
    	albumId = new String[albumCount];
    	albumArt = new Bitmap[albumCount];
    	int i =0;
    	
    	if(albumCursor.moveToFirst()){
    		do{
    			String albumName = albumCursor.getString(albumCursor.getColumnIndex(MediaStore.Audio.Albums.ALBUM));
				album[i] = albumName; 
				String albumid = albumCursor.getString(albumCursor.getColumnIndex(MediaStore.Audio.Albums._ID));
				albumId[i] = albumid; 
				
				for(int n=0;n<songAlbum.length;n++)
				{
					if(songAlbum[n].equals(album[i]))
					{	albumArt[i] = Bmap[n];
						
						break;
					}
					 
				}
							
    			i++;
    		}while(albumCursor.moveToNext());
    	}
    	
    	
    }
    
  
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_tab, menu);
        return true;
    }
    
    
   
    
}
