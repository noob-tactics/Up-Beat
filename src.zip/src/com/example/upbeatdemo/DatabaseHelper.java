package com.example.upbeatdemo;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.AvoidXfermode.Mode;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {
	String songs;
	 Cursor c;
		
	 private final static String DATABASE_NAME = "playlistManager";
	
	 private static final String TABLE_PLAYLIST = "playlist";
	 //private static final String TABLE_SONGS = "songs";
	 //private static final String TABLE_PLAYLIST_SONGS = "playlist_songs";
	
	
	
	public DatabaseHelper(Context context) {
		super(context, DATABASE_NAME, null, 1);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_PLAYLIST + "(_id INTEGER PRIMARY KEY AUTOINCREMENT , name_playlist VARCHAR , content VARCHAR)" );
		}

	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) {
		// TODO Auto-generated method stub
		 // on upgrade drop older tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PLAYLIST);
        
 
        // create new tables
        onCreate(db);
	}
	
	public void createPlaylist(Model_Playlist p){
		SQLiteDatabase db = getWritableDatabase();
		Log.d("in database", p.getPlaylistName()+"\n"+p.getContent());
		db.execSQL("INSERT INTO " + TABLE_PLAYLIST + "(" + "name_playlist" + "," + "content" + ") VALUES('" + p.getPlaylistName() + "','" + p.getContent() + "')");
		closeDB();
	}
	
	public Model_Playlist getSongsFromPlaylist(int id){
		
		String selectQuery = "SELECT * FROM  " + TABLE_PLAYLIST + " WHERE _id = '" + id +"'";
		SQLiteDatabase db = this.getWritableDatabase();
		Model_Playlist p;
		try{
			c = db.rawQuery(selectQuery, null);
			if(c!=null)
				c.moveToFirst();
				int pid = Integer.parseInt(c.getString(0));
				String pname = c.getString(1);
				String pcon = c.getString(2);
				p = new Model_Playlist(id,pname,pcon );
			    }
			    finally{
			    	 c.close();
			    	 closeDB();
			    }
		
		return p;
	}
	
	public ArrayList<Model_Playlist> getAllPlaylist() {
	    ArrayList<Model_Playlist> playlists = new ArrayList<Model_Playlist>();
	    
	    String selectQuery = "SELECT  * FROM " + TABLE_PLAYLIST;

	    SQLiteDatabase db = this.getWritableDatabase();
	    try{
	    c = db.rawQuery(selectQuery, null);
	   
	    //int count = c.getCount();
	    //String[] playlistName = new String[count];
	    int i =0;
	    // looping through all rows and adding to list
	    if (c.moveToFirst()) {
	        do {
	            Model_Playlist p = new Model_Playlist();
	            p.setId(c.getInt((c.getColumnIndex("_id"))));
	            p.setPlaylistName((c.getString(c.getColumnIndex("name_playlist"))));
	            p.setContent(c.getString(c.getColumnIndex("content")));
	 
	            // adding to playlist
	           // playlistName[i]=p.getPlaylistName();
	            playlists.add(p);
	            i++;
	        } while (c.moveToNext());
	    }
	    }
	    finally{
	    	 c.close();
	    	 closeDB();
	    }
	    return playlists;
	}
	
	public void deletePlaylist(Model_Playlist playlist) {
	    SQLiteDatabase db = this.getWritableDatabase();
	    db.delete(TABLE_PLAYLIST,"_id"+"= ?", new String[]{ String.valueOf(playlist.getId()) });
	    closeDB();
	}
	
	 public void closeDB() {
	        SQLiteDatabase db = this.getReadableDatabase();
	        if (db != null && db.isOpen())
	            db.close();
	    }
	 
	


}
