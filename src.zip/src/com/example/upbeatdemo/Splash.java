package com.example.upbeatdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class Splash extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash_logo);
		
		timer.start();
	
	}

	
	Thread timer = new Thread(){

		@Override
		public void run() {
			// TODO Auto-generated method stub
			//super.run();
			
			try{
				sleep(3000);
				
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
			finally{
				Intent i = new Intent(Splash.this,TabActivity.class);
				startActivity(i);
			}
		}
		
	};
	
	
}
