package com.example.upbeatdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class SongsAdapter extends ArrayAdapter<String>{
	Bitmap[] artwork;    
	String[] songtitle;
	String[] artist;
	String[] songduration; 
	Context c;
	LayoutInflater inflater;
		public SongsAdapter(Context context,String[] songs,String[] artist,Bitmap[] artwork,String[] duration) {
			super(context, R.layout.songlist_item,songs);
			// TODO Auto-generated constructor stub
			
			this.c=context;
			this.songtitle=songs;
			this.artist=artist;
			this.artwork=artwork;
			this.songduration=duration;
		}
		
		public class ViewHolder
		{
			TextView t1;
			TextView t2;
			TextView t3;
			ImageView i1;
		}
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			if(convertView == null)
			{
				inflater=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView=inflater.inflate(R.layout.songlist_item,null);
			}
			
			final ViewHolder holder=new ViewHolder();
			holder.t1=(TextView)convertView.findViewById(R.id.textView1);
			holder.t2=(TextView)convertView.findViewById(R.id.textView2);
			holder.t3=(TextView)convertView.findViewById(R.id.textView3);
			holder.i1=(ImageView)convertView.findViewById(R.id.imageViewsmall);
			
			
			holder.t1.setText(songtitle[position]);
			holder.t2.setText(artist[position]);
			
			long duration = Long.parseLong(songduration[position]);
			duration = duration/1000;
			int mnt = (int)duration/60;
			int sec = (int)duration%60;
			//Toast.makeText(c,mnt+"\n"+sec , Toast.LENGTH_LONG).show();
			
			try{
			holder.t3.setText(mnt+":"+sec);
				
			holder.i1.setImageBitmap(artwork[position]);
			}
			catch(NullPointerException e){
				e.printStackTrace();
			}
			return convertView;
		}
		

	}
