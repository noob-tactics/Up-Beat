package com.example.upbeatdemo;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SongsActivity extends ListActivity {
	
	
	ListView lv;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs);
       
        lv = (ListView) findViewById(android.R.id.list);
          
        try{
        	
       SongsAdapter adapter = new SongsAdapter(getApplicationContext(), TabActivity.songTitle, TabActivity.songArtist, TabActivity.Bmap, TabActivity.songDuration);     
       lv.setAdapter(adapter);
        }
        catch(NullPointerException e){
        	e.printStackTrace();
        }
        
        lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int position,
					long arg3) {
				// TODO Auto-generated method stub
				startActivity(new Intent(getApplicationContext(),Player.class).putExtra("pos", position));
			}
        	
		});
        
        
    }
	
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_songs, menu);
        return true;
    }

    
}
