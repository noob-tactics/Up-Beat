package com.example.upbeatdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class AlbumAdapter extends ArrayAdapter {
	Bitmap[] artwork;    
	String[] album; 
	Context c;
	int index = -1;
	LayoutInflater inflater;
		public AlbumAdapter(Context context,Bitmap[] artwork,String[] album) {
			super(context, R.layout.album_item,album);
			// TODO Auto-generated constructor stub
			
			this.c=context;
			this.artwork=artwork;
			this.album = album;
			
		}
		
		public class ViewHolder
		{
			TextView t1;
			ImageView i1;
		}
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			if(convertView == null)
			{
				inflater=(LayoutInflater)c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
				convertView=inflater.inflate(R.layout.album_item,null);
			}
			
			final ViewHolder holder=new ViewHolder();
			holder.t1=(TextView)convertView.findViewById(R.id.albumName);
			holder.i1=(ImageView)convertView.findViewById(R.id.albumArt);
			
			
			
			try{
			holder.t1.setText(album[position]);
			holder.i1.setImageBitmap(artwork[position]);
			}
			catch(NullPointerException e){
				e.printStackTrace();
			}
			
			
			
			
			return convertView;
		}
	
	
	
}
