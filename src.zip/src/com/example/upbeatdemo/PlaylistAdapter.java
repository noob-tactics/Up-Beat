package com.example.upbeatdemo;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.TextView;

public class PlaylistAdapter extends BaseAdapter implements ListAdapter {
	
	 ArrayList<Model_Playlist> list = new ArrayList<Model_Playlist>(); 
	static Context context; 
	
	public PlaylistAdapter(ArrayList<Model_Playlist> list, Context context) { 
	    this.list = list; 
	    this.context = context; 
	} 
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int pos) {
		// TODO Auto-generated method stub
		return list.get(pos);
	}

	@Override
	public long getItemId(int arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		
		View v = convertView;
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		v = inflater.inflate(R.layout.playlist_item,null);
		
		TextView tv = (TextView) v.findViewById(R.id.playlistText);
		tv.setText(list.get(position).getPlaylistName());
		
		Button b = (Button) v.findViewById(R.id.deletePlaylist);
		b.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				DatabaseHelper dh = new DatabaseHelper(context);
				Model_Playlist rowToRemove = new Model_Playlist();
				
				dh.deletePlaylist(list.get(position));
				 
				 list.remove(position);
		         notifyDataSetChanged();
			}
		});
		
		
		return v;
	}

}
