package com.example.upbeatdemo;

public class Model_Playlist {

	int id;
	String playlist_name;
	String content;
	public Model_Playlist(){
		
	}
	
	public Model_Playlist(int id, String name_playlist ,String content) {
		super();
		this.id = id;
		this.playlist_name = name_playlist;
		this.content = content;
	}
	
	// setters
		public void setId(int id) {
	        this.id = id;
	    }
	 
	    public void setPlaylistName(String note) {
	        this.playlist_name = note;
	    }
	
	    public void setContent(String content){
	    	this.content = content;
	    }
	    
	    // getters
	    public int getId() {
	        return this.id;
	    }
//	    public Model_Playlist getIem(int id){
//	    	 ;
//	    	return m;
//	    }
	    public String getPlaylistName() { 
	        return this.playlist_name;
	    }
	    public String getContent(){
	    	return this.content;
	    }
	 
}
