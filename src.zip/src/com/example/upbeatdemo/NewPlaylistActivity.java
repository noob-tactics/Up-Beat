package com.example.upbeatdemo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.util.SparseBooleanArray;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class NewPlaylistActivity extends Activity  {
	Button save;
	ListView lv;
	static String[] content;
	
	
	static ArrayList<Model_Playlist> playlists;
    EditText et;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_playlist);
        DatabaseHelper dh= new DatabaseHelper(getApplicationContext());
        
        
        lv = (ListView) findViewById(R.id.newplaylistView1);
        save = (Button) findViewById(R.id.button1);
        et = (EditText) findViewById(R.id.namePlaylist);
       
        
        
        
        
        
       
        try{
        	 SongsAdapter adapter = new SongsAdapter(getApplicationContext(), TabActivity.songTitle, TabActivity.songArtist, TabActivity.Bmap, TabActivity.songDuration);     
             lv.setAdapter(adapter);
        }
        catch(NullPointerException e){
        	e.printStackTrace();
        }
        // tv =(TextView) findViewById(R.id.textView1);
        
        
        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
       // lv.setItemChecked(2, true);
        
        lv.setOnItemClickListener(new OnItemClickListener() {
        	
        	
        	
			@Override
			public void onItemClick(AdapterView<?> arg0, View view, int position,
					long arg3) {
				
				// TODO Auto-generated method stub
				 SparseBooleanArray sp=lv.getCheckedItemPositions();
				 	content = new String[sp.size()];
				     String str = "";
				    for(int i=0;i<sp.size();i++)
				    {	try{
				        
				        str += TabActivity.songTitle[sp.keyAt(i)];
				        if(i<sp.size()-1){
			                str = str+strSeparator;
			            }
				        content= convertStringToArray(str);
				    	}
				    catch(NullPointerException e){
				    	e.printStackTrace();
				    }
				        
				    }    
				        
			}


	});
        
        save.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				 if(et.getText().toString().trim().length()==0 ){
					 	showMessage("ERROR", "Name Can't be Blank !!");
				 }
				 else{
					 String db_content = convertArrayToString(content);
					 DatabaseHelper dh = new DatabaseHelper(getApplicationContext());
					 Model_Playlist p = new Model_Playlist(1, et.getText().toString(), db_content);
					
					 dh.createPlaylist(p);
					 
					 final AlertDialog dialog = new AlertDialog.Builder(NewPlaylistActivity.this).create();
						dialog.setTitle("DONE");
						dialog.setMessage("Playlist Created");
						dialog.setButton("ok", new DialogInterface.OnClickListener() {
							
							@Override
							public void onClick(DialogInterface arg0, int arg1) {
								// TODO Auto-generated method stub
								int FLAG = 2;
								Intent i = new Intent(NewPlaylistActivity.this,TabActivity.class).putExtra("FLAG", FLAG);
								startActivity(i);
								dialog.dismiss();
						}
						
					});
						dialog.show();
				        
					 
					 
				 }
		}
		});
        
             
}
  
	public static String strSeparator = ",";
    public  String convertArrayToString(String[] array){
        String str = "";
        try{
        for (int i = 0;i<array.length; i++) {
            str = str+array[i];
            // Do not append comma at the end of last element
            if(i<array.length-1){
                str = str+strSeparator;
            }
        }
        }
        catch(NullPointerException e){
        	e.printStackTrace();
        }
        return str;
    }
    public static String[] convertStringToArray(String str){
        String[] arr = str.split(strSeparator);
        return arr;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_new_playlist, menu);
        return true;
    }

    public void showMessage(String title , String msg){
    	final AlertDialog dialog = new AlertDialog.Builder(NewPlaylistActivity.this).create();
		dialog.setTitle(title);
		dialog.setMessage(msg);
		dialog.setButton("cancel", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				dialog.dismiss();
				
				
			}
	});
		dialog.show();
    }
    
    public void clearMsg(){
    	et.setText("");
       }

 }

	