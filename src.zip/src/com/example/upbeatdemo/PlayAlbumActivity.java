package com.example.upbeatdemo;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

public class PlayAlbumActivity extends Activity {
	TextView tv;
	ListView lv;
	ArrayList<String> albumSongs= new ArrayList<String>();
	ArrayList<String> albumArtist = new ArrayList<String>();
	ArrayList<String>albumDuration = new ArrayList<String>();
	
	ArrayList<Bitmap> albumBmap = new ArrayList<Bitmap>();
	static String [] title,artist,duration;
	Bitmap [] b;
	int position; 
	boolean fromAlbum;
	int index =-1;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_album);
        
        tv = (TextView) findViewById(R.id.albumTitle);
        lv = (ListView) findViewById(R.id.albumSongs);
        
        Intent extra = getIntent();
        position = extra.getIntExtra("albumPos", 0);
        tv.setText(TabActivity.album[position]);
        getAlbumDetails();
        
        SongsAdapter adapter =new SongsAdapter(getApplicationContext(), title, artist, b, duration);
        lv.setAdapter(adapter);
        
       lv.setOnItemClickListener(new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			// TODO Auto-generated method stub
			for (int j=0;j<TabActivity.songTitle.length;j++) {
        	    if (TabActivity.songTitle[j].equals(title[arg2])) {
        	        index = j;
        	        break;
        	    }
        	}
			fromAlbum =true;
			Intent i = new Intent(PlayAlbumActivity.this,Player.class).putExtra("pos_album", index).putExtra("TAG", fromAlbum);
			startActivity(i);
			
			
		}
	});
    }
    
    public void getAlbumDetails(){
    	
    	
    		
    		for(int j =0;j<TabActivity.songAlbumId.length;j++){
    			
    			if(TabActivity.albumId[position].equals(TabActivity.songAlbumId[j])){
    				albumSongs.add(TabActivity.songTitle[j]);
    				albumArtist.add(TabActivity.songArtist[j]);
    				albumDuration.add(TabActivity.songDuration[j]);
    				albumBmap.add(TabActivity.Bmap[j]);
    			}	
    	}
    		title = new String[albumSongs.size()];
    		artist = new String[albumSongs.size()];
    		duration = new String[albumSongs.size()];
    		b =new Bitmap[albumSongs.size()];
    		for(int i =0;i<albumSongs.size();i++){
    			title[i] = albumSongs.get(i);
    			artist[i] = albumArtist.get(i);
    			duration[i] =albumDuration.get(i);
    			b[i] = albumBmap.get(i);
    		}
    		
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_play_album, menu);
        return true;
    }

    
}
