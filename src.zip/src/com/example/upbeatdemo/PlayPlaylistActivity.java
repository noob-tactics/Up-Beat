package com.example.upbeatdemo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;

public class PlayPlaylistActivity extends Activity {
    static String [] playlist_songs,playlist_artist,playlist_duration;
	Bitmap [] playlist_bmap;
	String PlaylistTitle;
	TextView tv;
	ListView lv;
	int position=0;
	int index = -1;
	boolean fromPlaylist;
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_playlist);
        
        Intent i = getIntent();
        playlist_songs = i.getStringArrayExtra("songs");
        
        int count = playlist_songs.length;
        playlist_artist = new String[count];
        playlist_duration = new String[count];
        playlist_bmap = new Bitmap[count];
        
        PlaylistTitle = i.getStringExtra("title");
        for(int k=0;k<playlist_songs.length;k++){
        for (int j=0;j<TabActivity.songTitle.length;j++) {
    	    if (TabActivity.songTitle[j].equals(playlist_songs[k])) {
    	        index = j;
    	        break;
    	    }
    	}
        playlist_artist[k] = TabActivity.songArtist[index];
        playlist_bmap[k] = TabActivity.Bmap[index];
        playlist_duration[k] = TabActivity.songDuration[index];
        }
        tv = (TextView) findViewById(R.id.title);
        lv = (ListView) findViewById(R.id.songList);
        tv.setText(PlaylistTitle);
        try{
        SongsAdapter adapter = new SongsAdapter(getApplicationContext(),playlist_songs,playlist_artist,playlist_bmap,playlist_duration);
        lv.setAdapter(adapter);
        }
        catch(NullPointerException e){
        	e.printStackTrace();
        }
        lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				
				for (int j=0;j<TabActivity.songTitle.length;j++) {
	        	    if (TabActivity.songTitle[j].equals(playlist_songs[arg2])) {
	        	        index = j;
	        	        break;
	        	    }
	        	}
				
				fromPlaylist = true;
				Intent i = new Intent(PlayPlaylistActivity.this,Player.class).putExtra("playlist_position",index).putExtra("FLAG", fromPlaylist);
				startActivity(i);
			}
		
        });
        
        
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_play_playlist, menu);
        return true;
    }

    
}
